const bcrypt = require("bcryptjs");
const User = require("../models/auth");
const jwt = require("jsonwebtoken");
const crypto = require("crypto"); // For generating random OTP
const transporter = require("../config/mail/mailconfig");


var company_name = "AlgoX"
const emailImagesLink =
  "https://threearrowstech.com/projects/gdsg/public/images/email-images/";
const noreply_email = "mails@elevatedmarketplace.world";

// Register a new user
exports.register = async (req, res) => {
  const { name, email, password } = req.body;

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ message: "Invalid email format" });
  }

  // Validate password length and content
  const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
  if (!passwordRegex.test(password)) {
    return res.status(400).json({
      message:
        "Password must be at least 8 characters long and contain both numbers and letters",
    });
  }

  const hashedPassword = await bcrypt.hash(password, 8);

  try {
    const existingEmail = await User.findOne({ email });
    if (existingEmail) {
      return res.status(400).json({ message: "User already exists" });
    }

    // Create new user with emailotp field set to null
    const userData = new User({
      name,
      email,
      password: hashedPassword,
      emailotp: null,
    });
    const user = await userData.save();
    res.status(200).json({ message: "User registered successfully!", user });
  } catch (error) {
    res.status(400).json({ message: "User cannot be registered", error });
  }
};

// Log in a user
exports.login = async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });

  if (!user) {
    return res.status(404).json({ message: "Authentication failed" });
  }

  const passwordMatched = await bcrypt.compare(password, user.password);
  if (!passwordMatched) {
    return res.status(404).json({ message: "Authentication failed" });
  }

  const token = jwt.sign(
    { id: user._id, email: user.email },
    process.env.SECRET_KEY,
    { expiresIn: "1h" }
  );
  res.cookie("token", token, { httpOnly: true });
  res.status(200).json({ message: "User logged in!", token });
};

exports.getProfile = async (req, res) => {
  try {
    const user = req.user;
    res.status(200).json({ status: "success", user });
  } catch (error) {
    res.status(400).json({ message: "Error fetching user profile", error });
  }
};
exports.changePassword = async (req, res) => {
  const { oldPassword, newPassword, confirmPassword } = req.body;

  // Validate input
  if (!oldPassword || !newPassword || !confirmPassword) {
    return res.status(400).json({ message: "All fields are required" });
  }

  if (newPassword !== confirmPassword) {
    return res
      .status(400)
      .json({ message: "New password and confirmation do not match" });
  }

  if (
    newPassword.length < 8 ||
    !/\d/.test(newPassword) ||
    !/[a-zA-Z]/.test(newPassword)
  ) {
    return res.status(400).json({
      message:
        "New password must be at least 8 characters long and contain both numbers and letters",
    });
  }

  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const passwordMatched = await bcrypt.compare(oldPassword, user.password);
    if (!passwordMatched) {
      return res.status(400).json({ message: "Old password is incorrect" });
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    user.emailotp = otp;
    await user.save();

    res
      .status(200)
      .json({ message: "OTP generated and saved successfully", otp });
  } catch (error) {
    res.status(500).json({ message: "Error changing password", error });
  }
};

exports.verifyOtp = async (req, res) => {
  const { otp: passwordotp, newPassword } = req.body;

  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res
      .status(401)
      .json({ success: false, message: "No token provided" });
  }

  try {
    const decodedToken = jwt.verify(token, process.env.SECRET_KEY);
    const userId = decodedToken.id;
    const user = await User.findById(userId);

    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }
    if (user.emailotp === passwordotp) {
      user.password = await bcrypt.hash(newPassword, 8);
      user.emailotp = "sjdfkjsd"; // Clear the OTP
      await user.save();

      return res
        .status(200)
        .json({ success: true, message: "Password changed successfully" });
    } else {
      return res.status(400).json({ success: false, message: "Invalid OTP" });
    }
  } catch (error) {
    console.error("Error verifying OTP:", error);
    return res
      .status(500)
      .json({ success: false, message: "Server error", error });
  }
};

exports.changeEmail = async (req, res) => {
  const { newEmail, oldEmail } = req.body;

  // Email validation
  if (!newEmail || !/\S+@\S+\.\S+/.test(newEmail)) {
    return res.status(400).json({
      message: "Please provide a valid new email address",
    });
  }

  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Check if the old email matches the user's current email
    if (user.email !== oldEmail) {
      return res.status(400).json({ message: "Old email is incorrect" });
    }

    // Check if the new email is already in use by another user
    const emailExists = await User.findOne({ email: newEmail });
    if (emailExists) {
      return res
        .status(400)
        .json({ message: "This email is already in use by another account" });
    }

    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // Save the new email and OTP in the user object
    user.newEmail = newEmail;
    user.newEmailOtp = otp;
    await user.save();

    console.log(`Generated OTP: ${otp}`); // Debugging line

    res
      .status(200)
      .json({ message: "OTP generated and sent to the new email", otp });
  } catch (error) {
    res.status(500).json({ message: "Error changing email", error });
  }
};

exports.verifyNewEmailOtp = async (req, res) => {
  const { emailotp, newEmail } = req.body;
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res
      .status(401)
      .json({ success: false, message: "No token provided" });
  }

  try {
    const decodedToken = jwt.verify(token, process.env.SECRET_KEY);
    const userId = decodedToken.id;

    const user = await User.findOne({ _id: userId });

    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    console.log(`Provided OTP: ${emailotp}`); // Debugging line
    console.log(`Stored OTP: ${user.newEmailOtp}`); // Debugging line

    if (user.newEmailOtp === emailotp) {
      user.email = newEmail; // Update the email to the new one

      await user.save();
      return res
        .status(200)
        .json({ success: true, message: "Email changed successfully" });
    } else {
      return res.status(400).json({ success: false, message: "Invalid OTP" });
    }
  } catch (error) {
    console.error("Error in verifyNewEmailOtp:", error); // Log the error details
    return res
      .status(500)
      .json({ success: false, message: "Server error", error: error.message });
  }
};

exports.sendOtp = async (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res
      .status(401)
      .json({ success: false, message: "No token provided" });
  }

  try {
    const decodedToken = jwt.verify(token, process.env.SECRET_KEY);
    const userId = decodedToken.id;
    const user = await User.findOne({ _id: userId });

    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    const otp = crypto.randomInt(100000, 999999).toString();



    const title = "OTP - Password Reset" ;
    const username = user.name;
    const email = user.email
    const emailimg = emailImagesLink + "passwordreset.png";
    const heading = "OTP For Password Reset";
    const subheading = "";
    const body = `Hello ${username},<br>You have requested a password reset on ${company_name} App. <b>${otp}</b> is your OTP for the request<br>`;

    const mailOptions = {
      from: {
        name: "AlgoX",
        address: noreply_email,
      },
      to: {
        name: username,
        address: email,
      },
      subject: "OTP - Password Reset AlgoX " + company_name,
      html: emailTemplate(title, emailimg, heading, subheading, body),
      text: "This is the plain text version of the email content",
    };

    transporter.sendMail(mailOptions, async (err, info) => {
      if (!err) {
        user.varifyemailotp = otp;
        await user.save();
    
        return res
          .status(200)
          .json({ success: true, message: "OTP sent successfully", otp });

      } else {
        res.status(400).json({
          status: "error",
          message: "Failed to send email",
        });
      }
    });


  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: "Server error", error });
  }
};

exports.verifyEmailOtp = async (req, res) => {
  const { emailVerifyOtp } = req.body;
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res
      .status(401)
      .json({ success: false, message: "No token provided" });
  }

  try {
    const decodedToken = jwt.verify(token, process.env.SECRET_KEY);
    const userId = decodedToken.id;

    const user = await User.findOne({ _id: userId });
    console.log("Varification email otp", user.varifyemailotp);

    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    if (user.varifyemailotp === emailVerifyOtp) {
      user.varifyemailotp = "verified";
      await user.save();

      return res
        .status(200)
        .json({ success: true, message: "Email verified successfully" });
    } else {
      return res.status(400).json({ success: false, message: "Invalid OTP" });
    }
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: "Server error", error });
  }
};