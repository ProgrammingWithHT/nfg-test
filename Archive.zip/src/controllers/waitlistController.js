const WaitlistUser = require('../models/waitlist');

exports.joinWaitlist = async (req, res) => {
  const { name, email } = req.body;

  try {
    const existingEmail = await WaitlistUser.findOne({ email });
    if (existingEmail) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const userData = new WaitlistUser({
      name,
      email,
      date: new Date().toUTCString(),
    });
    const waitlistUser = await userData.save();

    res.status(200).json({ message: 'User registered successfully!', waitlistUser });
  } catch (error) {
    res.status(400).json({ message: 'User cannot be registered', error });
  }
};
