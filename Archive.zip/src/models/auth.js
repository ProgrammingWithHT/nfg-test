
const mongoose = require('mongoose');

const userAuthSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    emailotp: { type: String },
    varifyemailotp: { type: String },
    newEmail: { type: String }, 
    newEmailOtp: { type: String },
  },
  { collection: 'userdata', versionKey: false }
);

const User = mongoose.model('User', userAuthSchema);

module.exports = User;
